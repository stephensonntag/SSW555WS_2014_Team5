package ssw555.project.team5.model;

public class GEDCOMFamily {
	private String identifier;
	private String husband;
	private String wife;
	private String type;
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getHusband() {
		return husband;
	}
	public void setHusband(String husband) {
		this.husband = husband;
	}
	public String getWife() {
		return wife;
	}
	public void setWife(String wife) {
		this.wife = wife;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}